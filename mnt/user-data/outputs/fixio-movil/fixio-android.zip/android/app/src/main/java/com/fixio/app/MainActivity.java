package com.fixio.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
