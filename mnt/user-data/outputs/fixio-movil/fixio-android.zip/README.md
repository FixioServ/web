# Fixio - Proyecto Android (Capacitor)

Este proyecto convierte la plataforma Fixio en una app Android real (APK).

## ANTES DE COMPILAR: configura la dirección del servidor

Edita `capacitor.config.json` y cambia la URL según tu escenario:

**Pruebas en tu red WiFi local** (tu PC corriendo `node server.js`):
```json
"server": { "url": "http://192.168.X.X:5500", "cleartext": true }
```
(la IP de tu PC la ves con `ipconfig`; el teléfono debe estar en el mismo WiFi)

**Producción** (cuando tengas dominio con HTTPS):
```json
"server": { "url": "https://tudominio.com", "cleartext": false }
```

## Cómo obtener el APK (elige UNA vía)

### Vía A - En la nube con GitHub Actions (sin instalar nada)
1. Crea un repositorio en https://github.com (puede ser privado).
2. Sube TODO el contenido de esta carpeta al repositorio
   (con GitHub Desktop, o arrastrando los archivos en la web de GitHub,
   o con git: `git init && git add . && git commit -m "Fixio" && git push`).
3. Entra a la pestaña **Actions** del repositorio. La compilación arranca sola
   (o pulsa "Run workflow" en "Compilar APK de Fixio").
4. En ~5 minutos, abre la ejecución terminada y descarga **fixio-apk-pruebas**
   desde la sección *Artifacts*. Dentro del zip está `app-debug.apk`.
5. Pasa el APK al teléfono (WhatsApp, cable, Drive) e instálalo
   (Android pedirá permitir "orígenes desconocidos": acéptalo).

> Nota: si cambias la URL en `capacitor.config.json`, haz push de nuevo y
> se compila otro APK automáticamente.

### Vía B - En tu PC con Android Studio
1. Instala Android Studio: https://developer.android.com/studio
2. En esta carpeta: `npm install` y luego `npx cap sync android`
3. Abre la carpeta `android/` con Android Studio y espera a que sincronice.
4. Menú Build -> Build App Bundle(s) / APK(s) -> Build APK(s).
5. El APK queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

## Para publicar en Play Store
El APK debug sirve para pruebas y distribución directa. Para la tienda
necesitas un paquete FIRMADO: sigue la guía `GUIA_APP_MOVIL.md` de la
plataforma (Vía Bubblewrap/TWA, la recomendada) o genera el bundle firmado
desde Android Studio (Build -> Generate Signed Bundle).
